import { createFileRoute } from "@tanstack/react-router";
import { useRoadmapStore } from "@/store/roadmap";
import { EmptyRoadmap } from "@/components/app/EmptyRoadmap";

export const Route = createFileRoute("/app/certifications")({
  head: () => ({
    meta: [
      { title: "Certifications — Pathwise" },
      { name: "description", content: "Certifications ranked by relevance to your target role — not a generic list." },
      { property: "og:title", content: "Certifications — Pathwise" },
      { property: "og:description", content: "Certifications ranked by relevance to your target role — not a generic list." },
    ],
  }),
  component: CertificationsPage,
});

const priorityStyle = {
  high: { bg: "color-mix(in oklab, var(--brand-amber) 20%, transparent)", color: "color-mix(in oklab, var(--brand-amber) 60%, black)" },
  medium: { bg: "color-mix(in oklab, var(--brand-blue) 15%, transparent)", color: "var(--brand-blue)" },
  low: { bg: "var(--secondary)", color: "var(--muted-foreground)" },
} as const;

const priorityLabel = { high: "High priority", medium: "Medium priority", low: "Lower priority" } as const;

function CertificationsPage() {
  const roadmap = useRoadmapStore((s) => s.roadmap);
  if (!roadmap) return <EmptyRoadmap label="certifications" />;

  return (
    <div className="mx-auto max-w-6xl px-6 py-10">
      <header className="mb-8">
        <p className="text-xs font-medium uppercase tracking-widest text-primary">Certifications</p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight" style={{ fontFamily: "var(--font-display)" }}>
          Credentials ranked for your path
        </h1>
      </header>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {roadmap.certifications.map((c) => {
          const s = priorityStyle[c.priority];
          return (
            <article key={c.title} className="flex flex-col rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-soft)] transition-transform hover:-translate-y-1">
              <span
                className="inline-flex w-fit items-center rounded-md px-2 py-0.5 text-xs font-medium"
                style={{ backgroundColor: s.bg, color: s.color }}
              >
                {priorityLabel[c.priority]}
              </span>
              <h3 className="mt-3 text-base font-semibold" style={{ fontFamily: "var(--font-display)" }}>{c.title}</h3>
              <div className="text-xs text-muted-foreground">{c.provider}</div>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{c.description}</p>
              <p className="mt-4 border-t border-border/60 pt-3 text-xs italic text-foreground/80">
                Why this fits: {c.whyThisFits}
              </p>
            </article>
          );
        })}
      </div>
    </div>
  );
}