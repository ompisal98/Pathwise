import { createFileRoute } from "@tanstack/react-router";
import { useRoadmapStore } from "@/store/roadmap";
import { EmptyRoadmap } from "@/components/app/EmptyRoadmap";

export const Route = createFileRoute("/app/projects")({
  head: () => ({
    meta: [
      { title: "Projects — Pathwise" },
      { name: "description", content: "Project ideas targeting the specific skill gaps in your roadmap." },
      { property: "og:title", content: "Projects — Pathwise" },
      { property: "og:description", content: "Project ideas targeting the specific skill gaps in your roadmap." },
    ],
  }),
  component: ProjectsPage,
});

function ProjectsPage() {
  const roadmap = useRoadmapStore((s) => s.roadmap);
  if (!roadmap) return <EmptyRoadmap label="projects" />;

  return (
    <div className="mx-auto max-w-6xl px-6 py-10">
      <header className="mb-8">
        <p className="text-xs font-medium uppercase tracking-widest text-primary">Projects</p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight" style={{ fontFamily: "var(--font-display)" }}>
          Build these to close your gaps
        </h1>
      </header>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {roadmap.projects.map((p) => (
          <article key={p.title} className="flex flex-col rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-soft)] transition-transform hover:-translate-y-1">
            <span
              className="inline-flex w-fit items-center rounded-md px-2 py-0.5 text-xs font-medium"
              style={{ backgroundColor: "color-mix(in oklab, var(--brand-blue) 15%, transparent)", color: "var(--brand-blue)" }}
            >
              Targets: {p.targets}
            </span>
            <h3 className="mt-3 text-base font-semibold" style={{ fontFamily: "var(--font-display)" }}>{p.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{p.description}</p>
            <p className="mt-4 border-t border-border/60 pt-3 text-xs italic text-foreground/80">
              Why this fits: {p.whyThisFits}
            </p>
          </article>
        ))}
      </div>
    </div>
  );
}