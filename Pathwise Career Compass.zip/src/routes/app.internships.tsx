import { createFileRoute } from "@tanstack/react-router";
import { useRoadmapStore } from "@/store/roadmap";
import { EmptyRoadmap } from "@/components/app/EmptyRoadmap";

export const Route = createFileRoute("/app/internships")({
  head: () => ({
    meta: [
      { title: "Internships — Pathwise" },
      { name: "description", content: "Internships matched to your profile, tagged within reach or reach." },
      { property: "og:title", content: "Internships — Pathwise" },
      { property: "og:description", content: "Internships matched to your profile, tagged within reach or reach." },
    ],
  }),
  component: InternshipsPage,
});

function InternshipsPage() {
  const roadmap = useRoadmapStore((s) => s.roadmap);
  if (!roadmap) return <EmptyRoadmap label="internships" />;

  return (
    <div className="mx-auto max-w-6xl px-6 py-10">
      <header className="mb-8">
        <p className="text-xs font-medium uppercase tracking-widest text-primary">Internships</p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight" style={{ fontFamily: "var(--font-display)" }}>
          Roles matched to your profile
        </h1>
      </header>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {roadmap.internships.map((i) => {
          const isReach = i.fit === "reach";
          return (
            <article key={i.title + i.company} className="flex flex-col rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-soft)] transition-transform hover:-translate-y-1">
              <span
                className="inline-flex w-fit items-center rounded-md px-2 py-0.5 text-xs font-medium"
                style={
                  isReach
                    ? { backgroundColor: "color-mix(in oklab, var(--brand-blue) 15%, transparent)", color: "var(--brand-blue)" }
                    : { backgroundColor: "color-mix(in oklab, var(--accent) 15%, transparent)", color: "var(--accent)" }
                }
              >
                {isReach ? "Reach" : "Within reach now"}
              </span>
              <h3 className="mt-3 text-base font-semibold" style={{ fontFamily: "var(--font-display)" }}>{i.title}</h3>
              <div className="text-xs text-muted-foreground">{i.company}</div>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{i.description}</p>
              <p className="mt-4 border-t border-border/60 pt-3 text-xs italic text-foreground/80">
                Why this fits: {i.whyThisFits}
              </p>
            </article>
          );
        })}
      </div>
    </div>
  );
}