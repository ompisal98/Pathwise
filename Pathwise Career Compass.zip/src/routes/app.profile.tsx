import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, Upload, Sparkles, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useRoadmapStore } from "@/store/roadmap";

export const Route = createFileRoute("/app/profile")({
  head: () => ({
    meta: [
      { title: "Profile — Pathwise" },
      { name: "description", content: "Share your resume, target role, interests, and grades to generate your personalized roadmap." },
      { property: "og:title", content: "Profile — Pathwise" },
      { property: "og:description", content: "Share your resume, target role, interests, and grades to generate your personalized roadmap." },
    ],
  }),
  component: ProfilePage,
});

const DEFAULT_RESUME =
  "Final-year CS student. Coursework: Data Structures, OS, DBMS, Algorithms.\nProjects: URL shortener (Java/Spring), Notes app (Python/Flask + Postgres).\nInternship: 2mo, wrote CRUD endpoints on a small internal tool.\nStrong in Java and Python. Basic SQL. No cloud/deploy experience yet.";

function ProfilePage() {
  const navigate = useNavigate();
  const { generate, loading } = useRoadmapStore();

  const [resume, setResume] = useState(DEFAULT_RESUME);
  const [targetRole, setTargetRole] = useState("Backend Engineer");
  const [interestInput, setInterestInput] = useState("");
  const [interests, setInterests] = useState<string[]>(["distributed systems", "fintech", "developer tools"]);
  const [grades, setGrades] = useState([
    { subject: "Data Structures", grade: "A" },
    { subject: "Databases", grade: "B+" },
    { subject: "Operating Systems", grade: "A-" },
  ]);

  function addInterest() {
    const v = interestInput.trim();
    if (!v) return;
    setInterests((p) => [...p, v]);
    setInterestInput("");
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    await generate({ resume, targetRole, interests, grades });
    navigate({ to: "/app/roadmap" });
  }

  return (
    <div className="mx-auto max-w-3xl px-6 py-10">
      <div className="mb-8">
        <h1 className="text-3xl font-semibold tracking-tight" style={{ fontFamily: "var(--font-display)" }}>
          Your profile
        </h1>
        <p className="mt-1.5 text-sm text-muted-foreground">
          The more specific your inputs, the more specific your roadmap.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        <section className="rounded-xl border border-border bg-card p-6 shadow-[var(--shadow-soft)]">
          <div className="flex items-center justify-between">
            <Label htmlFor="resume" className="text-base font-semibold">Resume</Label>
            <button
              type="button"
              className="inline-flex items-center gap-1.5 rounded-md border border-border px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
            >
              <Upload className="h-3.5 w-3.5" /> Upload file
            </button>
          </div>
          <Textarea
            id="resume"
            value={resume}
            onChange={(e) => setResume(e.target.value)}
            placeholder="Paste your resume text here..."
            className="mt-3 min-h-40 resize-y"
          />
        </section>

        <section className="rounded-xl border border-border bg-card p-6 shadow-[var(--shadow-soft)]">
          <Label htmlFor="role" className="text-base font-semibold">Target role</Label>
          <Input
            id="role"
            value={targetRole}
            onChange={(e) => setTargetRole(e.target.value)}
            placeholder="e.g. Backend Engineer"
            className="mt-3"
          />
        </section>

        <section className="rounded-xl border border-border bg-card p-6 shadow-[var(--shadow-soft)]">
          <Label className="text-base font-semibold">Interests</Label>
          <div className="mt-3 flex gap-2">
            <Input
              value={interestInput}
              onChange={(e) => setInterestInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  addInterest();
                }
              }}
              placeholder="Type an interest and press Enter"
            />
            <Button type="button" variant="outline" onClick={addInterest}>Add</Button>
          </div>
          {interests.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-2">
              {interests.map((tag, i) => (
                <span key={`${tag}-${i}`} className="inline-flex items-center gap-1.5 rounded-md border border-border bg-secondary px-2.5 py-1 text-xs">
                  {tag}
                  <button
                    type="button"
                    onClick={() => setInterests((p) => p.filter((_, idx) => idx !== i))}
                    className="text-muted-foreground hover:text-foreground"
                    aria-label={`Remove ${tag}`}
                  >
                    <X className="h-3 w-3" />
                  </button>
                </span>
              ))}
            </div>
          )}
        </section>

        <section className="rounded-xl border border-border bg-card p-6 shadow-[var(--shadow-soft)]">
          <Label className="text-base font-semibold">Academic record</Label>
          <div className="mt-3 space-y-2">
            {grades.map((g, i) => (
              <div key={i} className="flex gap-2">
                <Input
                  value={g.subject}
                  onChange={(e) => setGrades((p) => p.map((x, idx) => idx === i ? { ...x, subject: e.target.value } : x))}
                  placeholder="Subject"
                  className="flex-1"
                />
                <Input
                  value={g.grade}
                  onChange={(e) => setGrades((p) => p.map((x, idx) => idx === i ? { ...x, grade: e.target.value } : x))}
                  placeholder="Grade"
                  className="w-28"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => setGrades((p) => p.filter((_, idx) => idx !== i))}
                  aria-label="Remove subject"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
          <Button
            type="button"
            variant="outline"
            className="mt-3"
            onClick={() => setGrades((p) => [...p, { subject: "", grade: "" }])}
          >
            <Plus className="mr-1.5 h-4 w-4" /> Add subject
          </Button>
        </section>

        <button
          type="submit"
          disabled={loading}
          className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-lg bg-accent text-sm font-medium text-accent-foreground shadow-[var(--shadow-soft)] transition-all hover:-translate-y-0.5 hover:shadow-[var(--shadow-lift)] disabled:cursor-wait disabled:opacity-70"
        >
          <Sparkles className="h-4 w-4" />
          {loading ? "Generating your roadmap..." : "Generate my roadmap"}
        </button>
      </form>
    </div>
  );
}