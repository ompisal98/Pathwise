import { createFileRoute, Link } from "@tanstack/react-router";
import { Clock, Target } from "lucide-react";
import { useRoadmapStore } from "@/store/roadmap";

export const Route = createFileRoute("/app/roadmap")({
  head: () => ({
    meta: [
      { title: "Roadmap — Pathwise" },
      { name: "description", content: "Your phased career roadmap with skill gaps and time-boxed milestones." },
      { property: "og:title", content: "Roadmap — Pathwise" },
      { property: "og:description", content: "Your phased career roadmap with skill gaps and time-boxed milestones." },
    ],
  }),
  component: RoadmapPage,
});

function RoadmapPage() {
  const { roadmap, profile } = useRoadmapStore();

  if (!roadmap) return <EmptyState />;

  return (
    <div className="mx-auto max-w-4xl px-6 py-10">
      <div className="mb-8">
        <p className="text-xs font-medium uppercase tracking-widest text-primary">Your roadmap</p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight" style={{ fontFamily: "var(--font-display)" }}>
          Path to {profile?.targetRole ?? "your target role"}
        </h1>
      </div>

      <div className="mb-10 rounded-xl border border-border bg-card p-6 shadow-[var(--shadow-soft)]">
        <div className="flex items-center gap-2 text-primary">
          <Target className="h-4 w-4" />
          <h2 className="text-sm font-semibold uppercase tracking-wider">Key gaps identified</h2>
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {roadmap.gaps.map((g) => (
            <div key={g.title} className="rounded-lg border border-border/70 bg-background p-4">
              <div className="text-sm font-semibold" style={{ fontFamily: "var(--font-display)" }}>{g.title}</div>
              <div className="mt-1 text-xs leading-relaxed text-muted-foreground">{g.explanation}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="relative">
        <div aria-hidden className="absolute left-4 top-2 hidden h-[calc(100%-1rem)] w-px bg-border md:block" />
        <div className="space-y-6">
          {roadmap.phases.map((p, i) => (
            <div key={p.label} className="relative md:pl-14">
              <div className="absolute left-0 top-6 hidden h-8 w-8 items-center justify-center rounded-full border border-border bg-background text-xs font-semibold text-primary shadow-[var(--shadow-soft)] md:flex">
                {i + 1}
              </div>
              <div className="rounded-xl border border-border bg-card p-6 shadow-[var(--shadow-soft)]">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{p.label}</div>
                    <h3 className="mt-0.5 text-xl font-semibold" style={{ fontFamily: "var(--font-display)" }}>{p.title}</h3>
                  </div>
                  <div className="inline-flex items-center gap-1.5 rounded-full bg-secondary px-3 py-1 text-xs text-muted-foreground">
                    <Clock className="h-3.5 w-3.5" />
                    {p.duration}
                  </div>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{p.description}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {p.skills.map((s) => (
                    <span key={s} className="inline-flex items-center rounded-md border border-primary/20 bg-primary/5 px-2.5 py-1 text-xs font-medium text-primary">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="mx-auto max-w-md px-6 py-24 text-center">
      <h2 className="text-xl font-semibold" style={{ fontFamily: "var(--font-display)" }}>No roadmap yet</h2>
      <p className="mt-2 text-sm text-muted-foreground">
        Fill in your profile and we'll build your personalized roadmap.
      </p>
      <Link
        to="/app/profile"
        className="mt-6 inline-flex h-10 items-center rounded-lg bg-accent px-5 text-sm font-medium text-accent-foreground shadow-[var(--shadow-soft)] transition-all hover:-translate-y-0.5"
      >
        Go to profile
      </Link>
    </div>
  );
}