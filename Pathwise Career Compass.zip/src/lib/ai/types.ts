export interface Grade {
  subject: string;
  grade: string;
}

export interface Profile {
  resume: string;
  targetRole: string;
  interests: string[];
  grades: Grade[];
}

export interface Gap {
  title: string;
  explanation: string;
}

export interface Phase {
  label: string; // e.g. "Phase 1"
  title: string; // e.g. "Foundations"
  duration: string; // e.g. "4-6 weeks"
  description: string;
  skills: string[];
}

export type FitTag = "within-reach" | "reach";

export interface Internship {
  title: string;
  company: string;
  fit: FitTag;
  description: string;
  whyThisFits: string;
}

export interface Project {
  title: string;
  targets: string; // gap it targets
  description: string;
  whyThisFits: string;
}

export type CertPriority = "high" | "medium" | "low";

export interface Certification {
  title: string;
  provider: string;
  priority: CertPriority;
  description: string;
  whyThisFits: string;
}

export interface RoadmapResult {
  gaps: Gap[];
  phases: Phase[];
  internships: Internship[];
  projects: Project[];
  certifications: Certification[];
}