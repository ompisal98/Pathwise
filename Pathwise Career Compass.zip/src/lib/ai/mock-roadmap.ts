import type { RoadmapResult } from "./types";

// Sample persona: final-year CS student, target "Backend Engineer".
// Used both by the landing page preview and as the default mock output
// of generateRoadmap() when no AI endpoint is configured.
export const mockRoadmap: RoadmapResult = {
  gaps: [
    { title: "System design fundamentals", explanation: "Resume shows strong coding but no exposure to designing services at scale." },
    { title: "Cloud deployment (AWS/GCP)", explanation: "No deployment or infra experience listed — a core expectation for backend roles." },
    { title: "SQL query optimization", explanation: "Database work is basic CRUD; production backends require indexing and query planning." },
    { title: "Testing discipline", explanation: "Projects lack automated test coverage, which most engineering teams screen for." },
  ],
  phases: [
    {
      label: "Phase 1",
      title: "Foundations",
      duration: "4-6 weeks",
      description: "Shore up the day-to-day fundamentals every backend team assumes you have: relational databases, tests, and clean version control.",
      skills: ["SQL", "Testing", "Git workflows"],
    },
    {
      label: "Phase 2",
      title: "Systems",
      duration: "6-8 weeks",
      description: "Move from writing code to designing services — how requests flow, where things break, and how to keep them fast under load.",
      skills: ["System Design", "Caching", "Load Balancing"],
    },
    {
      label: "Phase 3",
      title: "Deployment",
      duration: "4 weeks",
      description: "Ship what you build. Learn the deployment path most fintech and mid-size teams actually use today.",
      skills: ["AWS", "Docker", "CI/CD"],
    },
  ],
  internships: [
    {
      title: "Backend Intern",
      company: "Mid-size fintech",
      fit: "within-reach",
      description: "Ship features on a Java/Spring backend with real production traffic and mentorship from senior engineers.",
      whyThisFits: "Your Java strength matches their stack, and the scope forgives your current gap in system design.",
    },
    {
      title: "SDE Intern",
      company: "Large tech co",
      fit: "reach",
      description: "Rotational program across distributed systems teams — high bar on system design and CS fundamentals.",
      whyThisFits: "Aim here after Phase 2 — your coding is ready, but the interview loop leans on the design skills you're building.",
    },
    {
      title: "Platform Intern",
      company: "Series-B SaaS",
      fit: "within-reach",
      description: "Own small internal tools end-to-end — from Postgres schema to a deployed API.",
      whyThisFits: "Perfect Phase 1 target: real SQL, real deployment, without needing distributed-systems depth.",
    },
  ],
  projects: [
    {
      title: "Build a rate limiter from scratch",
      targets: "System design",
      description: "Implement token-bucket and sliding-window limiters, then benchmark them under load.",
      whyThisFits: "Directly attacks your biggest gap — you'll be able to walk through a design decision in interviews.",
    },
    {
      title: "Deploy a REST API with CI/CD on AWS",
      targets: "Cloud deployment",
      description: "Take one of your existing Python projects, containerize it, and ship it through GitHub Actions to ECS.",
      whyThisFits: "Reuses code you already have, so the whole exercise is the deployment gap rather than starting over.",
    },
    {
      title: "Query-tune a 1M-row Postgres dataset",
      targets: "SQL optimization",
      description: "Load an open dataset, write intentionally slow queries, then use EXPLAIN and indexes to fix them.",
      whyThisFits: "Turns your basic SQL into the production skill hiring managers actually probe for.",
    },
  ],
  certifications: [
    {
      title: "AWS Certified Cloud Practitioner",
      provider: "Amazon Web Services",
      priority: "high",
      description: "Foundational AWS credential covering core services, pricing, and security.",
      whyThisFits: "Your Phase 3 focus is AWS — this credential signals it on your resume in weeks, not months.",
    },
    {
      title: "Postman API Fundamentals",
      provider: "Postman",
      priority: "low",
      description: "Short course on designing and documenting HTTP APIs with Postman.",
      whyThisFits: "Useful polish, but lower priority than shipping the deployment project above.",
    },
    {
      title: "MongoDB Associate Developer",
      provider: "MongoDB University",
      priority: "medium",
      description: "Data modeling and query patterns for document databases.",
      whyThisFits: "Complements your SQL work — many fintech backends run a mix of both.",
    },
  ],
};