import type { Profile, RoadmapResult } from "./types";
import { mockRoadmap } from "./mock-roadmap";

/**
 * generateRoadmap — single seam for AI integration.
 *
 * Today: returns mock data so the prototype is fully functional offline.
 *
 * Tomorrow: when VITE_AI_API_URL + VITE_AI_API_KEY are configured, POST the
 * profile to your LLM endpoint and return the parsed RoadmapResult. Do NOT
 * change any call sites — every consumer already awaits this function.
 *
 * Security note: because these are VITE_* vars they are inlined into the
 * client bundle. For production, proxy the call through a server function
 * (TanStack createServerFn) so the real key stays server-side.
 */
export async function generateRoadmap(profile: Profile): Promise<RoadmapResult> {
  const apiUrl = import.meta.env.VITE_AI_API_URL;
  const apiKey = import.meta.env.VITE_AI_API_KEY;

  if (apiUrl && apiKey) {
    // TODO: real fetch — swap this branch for the actual API call.
    // const res = await fetch(apiUrl, {
    //   method: "POST",
    //   headers: {
    //     "Content-Type": "application/json",
    //     Authorization: `Bearer ${apiKey}`,
    //   },
    //   body: JSON.stringify({ profile }),
    // });
    // if (!res.ok) throw new Error(`AI request failed: ${res.status}`);
    // return (await res.json()) as RoadmapResult;
  }

  // Simulate latency so the loading state is visible.
  await new Promise((r) => setTimeout(r, 900));
  return mockRoadmap;
}