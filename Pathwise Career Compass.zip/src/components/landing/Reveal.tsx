import type { ReactNode } from "react";
import { useInView } from "@/hooks/use-in-view";
import { cn } from "@/lib/utils";

interface RevealProps {
  children: ReactNode;
  delay?: number;
  className?: string;
  as?: "div" | "section";
}

export function Reveal({ children, delay = 0, className, as: Tag = "div" }: RevealProps) {
  const { ref, inView } = useInView<HTMLDivElement>();
  return (
    <Tag
      ref={ref as never}
      className={cn(className)}
      style={
        inView
          ? {
              opacity: 0,
              animation: `pw-in-up 0.7s cubic-bezier(0.22, 1, 0.36, 1) forwards`,
              animationDelay: `${delay}ms`,
            }
          : { opacity: 0 }
      }
    >
      {children}
    </Tag>
  );
}