import { FileText, Search, Map, Compass } from "lucide-react";
import { Reveal } from "./Reveal";

const items = [
  { icon: FileText, title: "Share your profile", body: "Upload your resume, list your interests, and enter your grades subject by subject." },
  { icon: Search, title: "AI cross-references your target role", body: "We match what you have against what a role like Backend Engineer actually expects." },
  { icon: Map, title: "Get a phased roadmap", body: "A time-boxed plan with your specific skill gaps called out — not generic advice." },
  { icon: Compass, title: "Receive matched next steps", body: "Internships, projects, and certifications selected for each phase of the plan." },
];

export function HowItWorks() {
  return (
    <section id="how" className="border-t border-border/60 bg-background">
      <div className="mx-auto max-w-6xl px-6 py-24">
        <Reveal>
          <div className="max-w-2xl">
            <p className="text-sm font-medium uppercase tracking-widest text-primary">How it works</p>
            <h2 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl" style={{ fontFamily: "var(--font-display)" }}>
              Four steps from profile to plan.
            </h2>
          </div>
        </Reveal>
        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {items.map((it, i) => (
            <Reveal key={it.title} delay={i * 80}>
              <div className="h-full rounded-xl border border-border bg-card p-6 shadow-[var(--shadow-soft)] transition-transform hover:-translate-y-1">
                <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary">
                  <it.icon className="h-5 w-5" strokeWidth={1.75} />
                </div>
                <div className="mt-4 text-xs font-medium text-muted-foreground">Step {i + 1}</div>
                <h3 className="mt-1 text-lg font-semibold" style={{ fontFamily: "var(--font-display)" }}>{it.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{it.body}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}