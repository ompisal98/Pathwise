import { mockRoadmap } from "@/lib/ai/mock-roadmap";
import { Reveal } from "./Reveal";
import { Clock } from "lucide-react";

export function SampleRoadmap() {
  const phases = mockRoadmap.phases;
  return (
    <section id="preview" className="border-t border-border/60 bg-background">
      <div className="mx-auto max-w-6xl px-6 py-24">
        <Reveal>
          <div className="max-w-2xl">
            <p className="text-sm font-medium uppercase tracking-widest text-primary">Sample roadmap</p>
            <h2 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl" style={{ fontFamily: "var(--font-display)" }}>
              What a Backend Engineer plan looks like.
            </h2>
            <p className="mt-3 text-muted-foreground">
              Generated for a final-year CS student with strong Java/Python and gaps in system design and cloud deployment.
            </p>
          </div>
        </Reveal>

        <div className="relative mt-14">
          <div aria-hidden className="absolute left-4 top-2 hidden h-[calc(100%-1rem)] w-px bg-border md:block" />
          <div className="space-y-6">
            {phases.map((p, i) => (
              <Reveal key={p.label} delay={i * 100}>
                <div className="relative md:pl-14">
                  <div className="absolute left-0 top-6 hidden h-8 w-8 items-center justify-center rounded-full border border-border bg-background text-xs font-semibold text-primary shadow-[var(--shadow-soft)] md:flex">
                    {i + 1}
                  </div>
                  <div className="rounded-xl border border-border bg-card p-6 shadow-[var(--shadow-soft)]">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{p.label}</div>
                        <h3 className="mt-0.5 text-xl font-semibold" style={{ fontFamily: "var(--font-display)" }}>{p.title}</h3>
                      </div>
                      <div className="inline-flex items-center gap-1.5 rounded-full bg-secondary px-3 py-1 text-xs text-muted-foreground">
                        <Clock className="h-3.5 w-3.5" />
                        {p.duration}
                      </div>
                    </div>
                    <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{p.description}</p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {p.skills.map((s) => (
                        <span
                          key={s}
                          className="inline-flex items-center rounded-md border border-primary/20 bg-primary/5 px-2.5 py-1 text-xs font-medium text-primary"
                        >
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}