import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { Reveal } from "./Reveal";

export function FinalCTA() {
  return (
    <section className="px-6 py-24">
      <Reveal>
        <div
          className="mx-auto max-w-5xl overflow-hidden rounded-2xl p-12 text-center shadow-[var(--shadow-lift)] sm:p-16"
          style={{
            background:
              "linear-gradient(135deg, var(--primary), color-mix(in oklab, var(--primary) 70%, black))",
          }}
        >
          <h2
            className="text-4xl font-semibold tracking-tight text-primary-foreground sm:text-5xl"
            style={{ fontFamily: "var(--font-display)", letterSpacing: "-0.02em" }}
          >
            Stop guessing. Start mapping.
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-primary-foreground/80">
            Get a roadmap tuned to your actual resume in under a minute.
          </p>
          <div className="mt-8">
            <Link
              to="/app/profile"
              className="group inline-flex h-11 items-center gap-2 rounded-lg bg-accent px-6 text-sm font-medium text-accent-foreground shadow-lg transition-all hover:-translate-y-0.5"
            >
              Launch demo
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
            </Link>
          </div>
        </div>
      </Reveal>
    </section>
  );
}