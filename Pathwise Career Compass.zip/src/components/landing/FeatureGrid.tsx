import { Route, Target, Briefcase, Hammer, Award, RefreshCw } from "lucide-react";
import { Reveal } from "./Reveal";

const features = [
  { icon: Route, title: "Personalized roadmap", body: "Built from your actual profile, not a template." },
  { icon: Target, title: "Gap analysis", body: "See exactly which skills are missing for your target role." },
  { icon: Briefcase, title: "Internship matching", body: "Tagged \"within reach now\" vs. \"reach\" so you apply strategically." },
  { icon: Hammer, title: "Project suggestions", body: "Each project targets a specific gap in your plan." },
  { icon: Award, title: "Certification filtering", body: "Ranked by relevance to your role — not a generic list." },
  { icon: RefreshCw, title: "Adaptive replanning", body: "The roadmap updates as you complete phases and add skills." },
];

export function FeatureGrid() {
  return (
    <section id="features" className="border-t border-border/60" style={{ backgroundColor: "color-mix(in oklab, var(--primary) 4%, var(--background))" }}>
      <div className="mx-auto max-w-6xl px-6 py-24">
        <Reveal>
          <div className="max-w-2xl">
            <p className="text-sm font-medium uppercase tracking-widest text-primary">What you get</p>
            <h2 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl" style={{ fontFamily: "var(--font-display)" }}>
              Every recommendation, tied to your inputs.
            </h2>
          </div>
        </Reveal>
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f, i) => (
            <Reveal key={f.title} delay={i * 60}>
              <div className="h-full rounded-xl border border-border bg-background p-6 transition-all hover:-translate-y-1 hover:shadow-[var(--shadow-soft)]">
                <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary">
                  <f.icon className="h-5 w-5" strokeWidth={1.75} />
                </div>
                <h3 className="mt-4 text-base font-semibold" style={{ fontFamily: "var(--font-display)" }}>{f.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{f.body}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}