import { Link } from "@tanstack/react-router";
import { ArrowRight, Upload, Sparkles, Route, Briefcase } from "lucide-react";
import { Reveal } from "./Reveal";

const steps = [
  { icon: Upload, label: "Upload profile" },
  { icon: Sparkles, label: "AI maps gaps" },
  { icon: Route, label: "Get phased roadmap" },
  { icon: Briefcase, label: "Internships · projects · certs" },
];

export function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 -top-40 h-[520px] opacity-60"
        style={{
          background:
            "radial-gradient(60% 60% at 50% 40%, color-mix(in oklab, var(--primary) 14%, transparent), transparent 70%)",
        }}
      />
      <div className="relative mx-auto max-w-5xl px-6 pb-16 pt-24 text-center sm:pt-32">
        <Reveal>
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-background/60 px-3 py-1 text-xs text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-accent" />
            Personalized to your resume — not a template
          </span>
        </Reveal>
        <Reveal delay={80}>
          <h1
            className="mt-6 text-5xl font-semibold tracking-tight text-foreground sm:text-6xl"
            style={{ fontFamily: "var(--font-display)", letterSpacing: "-0.02em" }}
          >
            Your career,{" "}
            <span className="text-primary">mapped to you</span>
          </h1>
        </Reveal>
        <Reveal delay={160}>
          <p className="mx-auto mt-5 max-w-2xl text-lg leading-relaxed text-muted-foreground">
            Pathwise reads your actual resume and grades, finds your real skill
            gaps against the role you want, and builds the roadmap to close them.
          </p>
        </Reveal>
        <Reveal delay={240}>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <Link
              to="/app/profile"
              className="group inline-flex h-11 items-center gap-2 rounded-lg bg-accent px-6 text-sm font-medium text-accent-foreground shadow-[var(--shadow-soft)] transition-all hover:-translate-y-0.5 hover:shadow-[var(--shadow-lift)]"
            >
              Launch demo
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
            </Link>
            <a href="#how" className="text-sm font-medium text-foreground/80 underline-offset-4 hover:text-foreground hover:underline">
              See how it works
            </a>
          </div>
        </Reveal>

        <Reveal delay={360}>
          <div className="mx-auto mt-16 max-w-4xl">
            <div className="relative flex items-center justify-between gap-4">
              <div
                aria-hidden
                className="absolute left-6 right-6 top-1/2 hidden h-px -translate-y-1/2 bg-border sm:block"
              />
              {steps.map((s, i) => (
                <div key={s.label} className="relative z-10 flex flex-1 flex-col items-center gap-2">
                  <div className="grid h-11 w-11 place-items-center rounded-full border border-border bg-background text-primary shadow-[var(--shadow-soft)]">
                    <s.icon className="h-4.5 w-4.5" strokeWidth={1.75} />
                  </div>
                  <span className="text-center text-xs font-medium text-muted-foreground">
                    {i + 1}. {s.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}