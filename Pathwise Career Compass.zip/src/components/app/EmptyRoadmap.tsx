import { Link } from "@tanstack/react-router";

export function EmptyRoadmap({ label }: { label: string }) {
  return (
    <div className="mx-auto max-w-md px-6 py-24 text-center">
      <h2 className="text-xl font-semibold" style={{ fontFamily: "var(--font-display)" }}>No {label} yet</h2>
      <p className="mt-2 text-sm text-muted-foreground">Generate your roadmap first to see matched {label}.</p>
      <Link
        to="/app/profile"
        className="mt-6 inline-flex h-10 items-center rounded-lg bg-accent px-5 text-sm font-medium text-accent-foreground shadow-[var(--shadow-soft)] transition-all hover:-translate-y-0.5"
      >
        Go to profile
      </Link>
    </div>
  );
}