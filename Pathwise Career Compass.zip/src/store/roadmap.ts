import { create } from "zustand";
import type { Profile, RoadmapResult } from "@/lib/ai/types";
import { generateRoadmap } from "@/lib/ai/roadmap-service";

interface RoadmapState {
  profile: Profile | null;
  roadmap: RoadmapResult | null;
  loading: boolean;
  error: string | null;
  generate: (profile: Profile) => Promise<void>;
  reset: () => void;
}

export const useRoadmapStore = create<RoadmapState>((set) => ({
  profile: null,
  roadmap: null,
  loading: false,
  error: null,
  generate: async (profile) => {
    set({ loading: true, error: null, profile });
    try {
      const roadmap = await generateRoadmap(profile);
      set({ roadmap, loading: false });
    } catch (e) {
      set({ error: e instanceof Error ? e.message : "Something went wrong", loading: false });
    }
  },
  reset: () => set({ profile: null, roadmap: null, error: null }),
}));