# Pathwise — Build Plan

AI-powered career roadmap platform. Frontend-only prototype with mock data, structured so a real LLM call can drop in later without refactoring.

## Design system (src/styles.css)

Replace default tokens with Pathwise palette (converted to oklch):
- `--primary` teal `#0F5C5C`, `--accent` coral `#FF6B5B` (CTAs), plus custom `--brand-blue` `#5B8DEF`, `--brand-amber` `#F5A623`
- `--background` `#FAFAF8`, `--foreground` `#12181A`
- Radius 10px, soft shadow token `--shadow-soft: 0 1px 2px rgba(0,0,0,.04), 0 8px 24px -12px rgba(0,0,0,.08)`
- Fonts: Space Grotesk (headings), Inter (body) via `<link>` tags in `__root.tsx` head; register `--font-display` and `--font-sans` in `@theme`
- Add motion utilities: fade-slide-up keyframes + `.animate-in-up` with stagger delays

Dark mode not in scope (not requested).

## Routes (file-based, TanStack)

```
src/routes/
  __root.tsx          → fonts, meta, QueryClientProvider (existing)
  index.tsx           → Landing page (replaces placeholder)
  app.tsx             → App shell layout (sidebar + <Outlet />)
  app.index.tsx       → redirect to /app/profile
  app.profile.tsx     → Profile input page
  app.roadmap.tsx     → Roadmap timeline
  app.internships.tsx → Card grid
  app.projects.tsx    → Card grid
  app.certifications.tsx → Card grid
```

Each route defines its own `head()` with unique title/description/og tags.

## Landing page sections (src/routes/index.tsx + components)

Components under `src/components/landing/`:
1. `Hero.tsx` — headline, sub, coral "Launch demo" → `/app/profile`, secondary anchor "See how it works" → `#how`
2. `StepStrip.tsx` — 4 steps connected by thin line, icons from lucide
3. `HowItWorks.tsx` — 4 cards
4. `FeatureGrid.tsx` — 6 feature cards
5. `SampleRoadmap.tsx` — visual timeline preview using shared sample data
6. `FinalCTA.tsx` — teal band, coral button
7. `Footer.tsx`

Scroll-triggered fade/slide-up via IntersectionObserver hook (`src/hooks/use-in-view.ts`) + stagger via CSS delay.

## App shell

- `src/components/app/AppSidebar.tsx` — shadcn Sidebar, 5 nav items with lucide icons, active state teal, `collapsible="icon"`; `SidebarTrigger` in header for mobile.
- Layout in `app.tsx` uses `SidebarProvider` + `<Outlet />`.

### Profile page
Form using shadcn Input/Textarea/Button. Fields: resume textarea + "Upload file" (visual), target role, interests (comma tag input), dynamic subject/grade rows with "+ Add subject". Coral full-width "Generate my roadmap" button → calls `generateRoadmap(profile)` then navigates to `/app/roadmap`. Persist result in a Zustand store (lightweight) or React Query cache keyed on profile hash — plan: use a small Zustand store at `src/store/roadmap.ts` for simplicity.

### Roadmap page
Reads store; renders "Key gaps identified" summary card + vertical timeline of phase cards. If empty, prompts back to Profile.

### Internships / Projects / Certifications
Read matching arrays from store; responsive grid (`grid-cols-1 md:grid-cols-2 lg:grid-cols-3`); cards with category badge (coral "within reach now" / blue "reach" / amber "high priority"), title, 2-line description, italic "why this fits".

## AI swap seam (key deliverable)

`src/lib/ai/roadmap-service.ts`:
```ts
export interface Profile { resume: string; targetRole: string; interests: string[]; grades: { subject: string; grade: string }[] }
export interface RoadmapResult { gaps: Gap[]; phases: Phase[]; internships: Internship[]; projects: Project[]; certifications: Certification[] }
export async function generateRoadmap(p: Profile): Promise<RoadmapResult> { ... }
```

Internally checks `import.meta.env.VITE_AI_API_URL` + `VITE_AI_API_KEY`; if unset, returns mock from `src/lib/ai/mock-roadmap.ts` (the Backend Engineer sample data). If set, currently still returns mock but a `// TODO: real fetch` comment shows exactly where to POST. This isolates the swap to one file.

Mock data lives in `src/lib/ai/mock-roadmap.ts` and is also imported by `SampleRoadmap.tsx` so landing preview matches app output.

## Secrets / env

Create `.env.example` with:
```
VITE_AI_API_KEY=
VITE_AI_API_URL=
```
No real values, no invented placeholders. `.env` is already gitignored. Since these are `VITE_*` they'll be inlined client-side — noted in a code comment that a production build should proxy through a server function to keep the key private (out of scope for this prototype).

## Dependencies to add

- `zustand` (roadmap store)
- Google Fonts loaded via `<link>` in `__root.tsx` (no new package)

Everything else (shadcn ui, lucide, tailwind) is already present.

## Out of scope (confirming)

- No auth, no database, no Lovable Cloud — pure frontend prototype
- File upload is visual-only (no parsing)
- No real LLM call yet — mock returns instantly

## Files created/modified

Modified: `src/styles.css`, `src/routes/__root.tsx`, `src/routes/index.tsx`
Created: 5 app routes, ~7 landing components, `AppSidebar`, `use-in-view` hook, `roadmap-service.ts`, `mock-roadmap.ts`, `store/roadmap.ts`, `.env.example`

Ready to build on approval.